// ══════════════════════════════════════════════════════════════════════════════
//  CIBS UNIFIED BACKEND — Master Google Apps Script v3.0
//  Central Institute of Behavioural Sciences, Nagpur
//  Dr. Shailesh V. Pangaonkar | Dr. Deepali S. Pangaonkar
//
//  DEPLOYMENT INSTRUCTIONS:
//  1. Open script.google.com → New Project → paste this entire file
//  2. Click Deploy → New Deployment → Web App
//     Execute as: Me | Who has access: Anyone (anonymous)
//  3. Copy the Web App URL → paste into APPS_SCRIPT_URL in all instruments
//  4. The script auto-creates all sheets on first run
//
//  SHEET STRUCTURE (auto-created):
//   • ADULT_BATTERY   — one row per adult subject (VISTA + VALID)
//   • CHILD_BATTERY   — one row per child (eSMART C + P + V)
//   • HUB_WORKERS     — ANM/MHW registry
//   • LINKS_ISSUED    — issued assessment links log
//   • AUDIT_LOG       — every submission with timestamp
//   • CONFIG          — settings & passwords
// ══════════════════════════════════════════════════════════════════════════════

// ── CONFIGURATION ─────────────────────────────────────────────────────────────
const MASTER_PASSWORD  = "CIBS_MASTER_2026";
const HUB_PASSWORD     = "CIBS_HUB_2026";
const SHEET_ID         = SpreadsheetApp.getActiveSpreadsheet().getId();
const VERSION          = "3.0";

// ── SHEET NAMES ───────────────────────────────────────────────────────────────
const SH = {
  ADULT:   "ADULT_BATTERY",
  CHILD:   "CHILD_BATTERY",
  HUB:     "HUB_WORKERS",
  LINKS:   "LINKS_ISSUED",
  AUDIT:   "AUDIT_LOG",
  CONFIG:  "CONFIG",
};

// ══════════════════════════════════════════════════════════════════════════════
//  ADULT BATTERY COLUMNS (VISTA + VALID, one row per subject)
// ══════════════════════════════════════════════════════════════════════════════
const ADULT_COLS = [
  // ── Identity ──
  "UID",                  // AV-XXXXXX-DDMMYY-G  (primary key)
  "Mobile",              // used for re-test detection (hashed)
  "FileNo",              // optional CIBS file number
  "Name",
  "Age",
  "Gender",
  "Education",
  "Setting",
  "Language",
  "Device",
  // ── Consent / Assent ──
  "VISTA_Consent",       // "YES"
  "VISTA_Consent_DT",    // ISO datetime of consent
  "VALID_Consent",       // "YES"
  "VALID_Consent_DT",    // ISO datetime of consent
  // ── VISTA timestamps ──
  "VISTA_Start_DT",
  "VISTA_Submit_DT",
  // ── VALID timestamps ──
  "VALID_Start_DT",
  "VALID_Submit_DT",
  // ── VISTA Domain scores ──
  "VISTA_CQ",
  "VISTA_ShapeCode",
  "VISTA_ColorCode",
  "VISTA_ShadeCode",
  "VISTA_SmileyCode",
  "VISTA_Big5_O","VISTA_Big5_C","VISTA_Big5_E","VISTA_Big5_A","VISTA_Big5_N",
  "VISTA_EQ",
  "VISTA_MHI","VISTA_PHI","VISTA_SFI","VISTA_OWC",
  "VISTA_CRIX","VISTA_SISRI","VISTA_SUDRI","VISTA_Urgency",
  "VISTA_Report_URL",
  // ── VALID Domain 1 — Cognition (Ravens CAT) ──
  "VALID_CQ","VALID_CQ_Band","VALID_Pctile","VALID_MA","VALID_CAT_Band","VALID_CAT_Correct","VALID_CAT_Total",
  // ── VALID Domain 2 — BFI-10 ──
  "VALID_BFI_O","VALID_BFI_C","VALID_BFI_E","VALID_BFI_A","VALID_BFI_N",
  // ── VALID Domain 2 — PID-5-BF ──
  "VALID_PID5_NA","VALID_PID5_DE","VALID_PID5_AN","VALID_PID5_DI","VALID_PID5_PS",
  "VALID_DSM_Cluster",
  // ── VALID Domain 3 — Health ──
  "VALID_WHO5","VALID_WHO5_Level",
  "VALID_PHQ9","VALID_PHQ9_Level",
  "VALID_GAD7","VALID_GAD7_Level",
  "VALID_RSES","VALID_RSES_Level",
  // ── VALID Domain 4 — Risk ──
  "VALID_CSSRS_Level","VALID_CSSRS_Label",
  "VALID_AUDIT_Score","VALID_AUDIT_Label",
  // ── Convergent Validity (computed post-hoc) ──
  "CV_D1_r","CV_D2_r","CV_D3_r","CV_D4_r","CV_D5_r",
  // ── Metadata ──
  "VISTA_Examiner","VALID_Examiner",
  "VISTA_VALID_Linked",   // "YES" if both instruments completed
  "Retest_Count",         // 0 = first assessment
  "Retest_Previous_UID",
  "Last_Updated",
];

// ══════════════════════════════════════════════════════════════════════════════
//  CHILD BATTERY COLUMNS (eSMART C + P + V, one row per child)
// ══════════════════════════════════════════════════════════════════════════════
const CHILD_COLS = [
  // ── Identity ──
  "FileNo",             // CH-[CENTERCODE]-[YY]-[NNNN]  (primary key)
  "Mobile_Parent",      // for re-test detection
  "ChildName",
  "DOB",
  "AgeYrs",
  "Gender",
  "School",
  "Grade",
  "AgeGroup",           // pre/pri/sec/hig
  // ── Consent / Assent ──
  "C_Consent",          // eSMART-C consent (clinician/examiner)
  "C_Consent_DT",
  "C_Assent",           // child assent
  "C_Assent_DT",
  "P_Consent",          // eSMART-P parental consent
  "P_Consent_DT",
  "V_Consent",          // eSMART-V clinician consent
  "V_Consent_DT",
  // ── eSMART-C timestamps ──
  "C_Start_DT",
  "C_Submit_DT",
  "C_Examiner",
  // ── eSMART-P timestamps ──
  "P_Start_DT",
  "P_Submit_DT",
  "P_Informant",
  "P_Relation",
  // ── eSMART-V timestamps ──
  "V_Start_DT",
  "V_Submit_DT",
  "V_Clinician",
  // ── eSMART-C: CIBS-FIS ──
  "C_FIS_Scale","C_FIS_RawTotal","C_FIS_MA","C_FIS_IQ","C_FIS_IQBand","C_FIS_Pct",
  "C_FIS_SER","C_FIS_CLS","C_FIS_MAT","C_FIS_CON",
  // ── eSMART-C: SCSS ──
  "C_ShapeCode","C_ColorCode","C_ShadeCode","C_SmileyCode",
  "C_CQ","C_IQBand_SCSS","C_EQSS","C_EQBand",
  "C_MHI","C_AnxIdx","C_AnxLevel","C_DepIdx","C_DepLevel",
  "C_SFI","C_WBI","C_DSMCluster","C_SIR","C_SUR","C_CDR","C_CRI",
  // ── eSMART-P: Perinatal ──
  "P_PeriRiskLevel","P_PeriRiskCount",
  // ── eSMART-P: Domain scores ──
  "P_IDD_score","P_IDD_sev",
  "P_ADHD_score","P_ADHD_sev",
  "P_ASD_score","P_ASD_sev",
  "P_SLD_score","P_SLD_sev",
  "P_MDD_score","P_MDD_sev",
  "P_ANX_score","P_ANX_sev",
  "P_ODD_score","P_ODD_sev",
  "P_CD_score","P_CD_sev",
  "P_RiskTag","P_SuicideFlag",
  // ── eSMART-V: Gold standard cognitive ──
  "V_MISIC_FSIQ","V_WISC_FSIQ","V_RAVENS_Pct","V_CFIT_IQ",
  "V_VABS_ABC","V_CARS_Total","V_SNAP_Total","V_CDI_Total","V_SCARED_Total","V_SDQ_Total",
  // ── eSMART-V: Diagnoses ──
  "V_IDD_Dx","V_IDD_Code","V_IDD_Sev",
  "V_ADHD_Dx","V_ADHD_Code","V_ADHD_Sev",
  "V_ASD_Dx","V_ASD_Code","V_ASD_Sev",
  "V_SLD_Dx","V_SLD_Code","V_SLD_Sev",
  "V_MDD_Dx","V_MDD_Code","V_MDD_Sev",
  "V_ANX_Dx","V_ANX_Code","V_ANX_Sev",
  "V_ODD_Dx","V_ODD_Code","V_ODD_Sev",
  "V_CD_Dx","V_CD_Code","V_CD_Sev",
  // ── eSMART-V: Clinical ──
  "V_SIR","V_SUR","V_CDR","V_Prognosis","V_NextReview",
  "V_Impression","V_Treatment",
  // ── Completion status ──
  "C_Complete","P_Complete","V_Complete",
  "All_Complete",        // YES when all 3 done
  "Retest_Count",
  "Last_Updated",
];

// ══════════════════════════════════════════════════════════════════════════════
//  HUB WORKER COLUMNS
// ══════════════════════════════════════════════════════════════════════════════
const HUB_COLS = [
  "HubID","HubName","Role","Mobile","Village","District","State",
  "CenterCode","CreatedDT","LastActiveDT","SubjectsAssigned","Password",
  "Active",
];

// ══════════════════════════════════════════════════════════════════════════════
//  ENTRY POINT — handles all HTTP POST requests
// ══════════════════════════════════════════════════════════════════════════════
function doPost(e) {
  const CORS = ContentService.createTextOutput;

  try {
    const raw     = e.postData ? e.postData.contents : "{}";
    const payload = JSON.parse(raw);
    const source  = (payload.Source || payload.source || "").toLowerCase();

    let result;

    // ── Route by source ──────────────────────────────────────────────────────
    if (source === "vista")           result = handleVISTA(payload);
    else if (source === "valid-standalone" || source === "valid")
                                       result = handleVALID(payload);
    else if (source === "esmart-c")   result = handleChild(payload, "C");
    else if (source === "esmart-p")   result = handleChild(payload, "P");
    else if (source === "esmart-v")   result = handleChild(payload, "V");
    else if (source === "hub-admin")  result = handleHub(payload);
    else if (source === "hub-read")   result = handleRead(payload);
    else if (source === "export")     result = handleExport(payload);
    else                              result = { status:"error", msg:"Unknown source: " + source };

    // ── Audit log every submission ──────────────────────────────────────────
    writeAudit(source, payload.UID || payload.FileNo || "?", result.status, raw.length);

    return CORS(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);

  } catch(err) {
    writeAudit("ERROR", "?", "exception", 0);
    return ContentService.createTextOutput(
      JSON.stringify({ status:"error", msg: err.toString() })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  // Health check + read endpoint
  const action = e.parameter ? e.parameter.action : null;
  if (action === "read") {
    return handleRead({ sheet: e.parameter.sheet, auth: e.parameter.auth });
  }
  return ContentService.createTextOutput(
    JSON.stringify({ status:"ok", version:VERSION, ts: new Date().toISOString() })
  ).setMimeType(ContentService.MimeType.JSON);
}

// ══════════════════════════════════════════════════════════════════════════════
//  VISTA HANDLER
// ══════════════════════════════════════════════════════════════════════════════
function handleVISTA(p) {
  ensureSheet(SH.ADULT, ADULT_COLS);
  const sh  = getSheet(SH.ADULT);
  const uid = p.UID || generateAdultUID(p.Mobile, p.Gender);
  const now = new Date().toISOString();

  // Re-test detection
  const existing = findRow(sh, "UID", uid);
  const retestCount = existing ? (Number(getCellValue(sh, existing, "Retest_Count")) || 0) : 0;

  const row = existing || null;
  const data = {
    UID:                uid,
    Mobile:             hashMobile(p.Mobile || ""),
    FileNo:             p.FileNo || "",
    Name:               p.Name || "",
    Age:                p.Age || "",
    Gender:             p.Gender || "",
    Education:          p.Education || "",
    Setting:            p.Setting || "",
    Language:           p.Language || "en",
    Device:             p.Device || "",
    VISTA_Consent:      p.VISTA_Consent || "YES",
    VISTA_Consent_DT:   p.VISTA_Consent_DT || now,
    VISTA_Start_DT:     p.VISTA_Start_DT || now,
    VISTA_Submit_DT:    now,
    VISTA_CQ:           p["VISTA CQ"] || p.VISTA_CQ || "",
    VISTA_ShapeCode:    p.ShapeCode || "",
    VISTA_ColorCode:    p.ColorCode || "",
    VISTA_ShadeCode:    p.ShadeCode || "",
    VISTA_SmileyCode:   p.SmileyCode || "",
    VISTA_Big5_O:       p["VISTA O"] || "",
    VISTA_Big5_C:       p["VISTA C"] || "",
    VISTA_Big5_E:       p["VISTA E"] || "",
    VISTA_Big5_A:       p["VISTA A"] || "",
    VISTA_Big5_N:       p["VISTA N"] || "",
    VISTA_EQ:           p["VISTA EQ"] || "",
    VISTA_MHI:          p["VISTA MHI"] || "",
    VISTA_PHI:          p["VISTA PHI"] || "",
    VISTA_SFI:          p["VISTA SFI"] || "",
    VISTA_OWC:          p["VISTA OWC"] || "",
    VISTA_CRIX:         p["VISTA CRIX"] || "",
    VISTA_SISRI:        p["VISTA SISRI"] || "",
    VISTA_SUDRI:        p["VISTA SUDRI"] || "",
    VISTA_Urgency:      p["VISTA Urgency"] || "",
    VISTA_Examiner:     p.Examiner || "",
    Retest_Count:       retestCount,
    VISTA_VALID_Linked: "VISTA_ONLY",
    Last_Updated:       now,
  };

  upsertRow(sh, ADULT_COLS, data, existing, "UID");
  return { status:"ok", uid, retest: retestCount > 0, retestCount, action: existing ? "updated" : "created" };
}

// ══════════════════════════════════════════════════════════════════════════════
//  VALID HANDLER — finds existing VISTA row by UID or mobile, updates in place
// ══════════════════════════════════════════════════════════════════════════════
function handleVALID(p) {
  ensureSheet(SH.ADULT, ADULT_COLS);
  const sh  = getSheet(SH.ADULT);
  const uid = p.UID || p.vistaUID || "";
  const now = new Date().toISOString();

  // Try to find existing VISTA row first
  let existing = uid ? findRow(sh, "UID", uid) : null;
  if (!existing && p.Mobile) {
    existing = findRowByMobile(sh, hashMobile(p.Mobile));
  }

  const retestCount = existing ? (Number(getCellValue(sh, existing, "Retest_Count")) || 0) : 0;

  const data = {
    UID:                uid || generateAdultUID(p.Mobile, p.Gender),
    Mobile:             hashMobile(p.Mobile || ""),
    Name:               p.Name || "",
    Age:                p.Age || "",
    Gender:             p.Gender || "",
    Education:          p.Education || "",
    Language:           p.Language || "en",
    VALID_Consent:      "YES",
    VALID_Consent_DT:   p.VALID_Consent_DT || now,
    VALID_Start_DT:     p.VALID_Start_DT || now,
    VALID_Submit_DT:    now,
    // Cognitive
    VALID_CQ:           p["VALID CQ"] || "",
    VALID_CQ_Band:      p["VALID CQ Band"] || "",
    VALID_Pctile:       p["VALID Percentile"] || "",
    VALID_MA:           p["VALID MA"] || "",
    VALID_CAT_Band:     p["VALID CAT Band"] || "",
    // BFI-10
    VALID_BFI_O:        p["VALID BFI-O"] || "",
    VALID_BFI_C:        p["VALID BFI-C"] || "",
    VALID_BFI_E:        p["VALID BFI-E"] || "",
    VALID_BFI_A:        p["VALID BFI-A"] || "",
    VALID_BFI_N:        p["VALID BFI-N"] || "",
    // PID-5-BF
    VALID_PID5_NA:      p["VALID PID5 Neg Affect"] || "",
    VALID_PID5_DE:      p["VALID PID5 Detachment"] || "",
    VALID_PID5_AN:      p["VALID PID5 Antagonism"] || "",
    VALID_PID5_DI:      p["VALID PID5 Disinhibition"] || "",
    VALID_PID5_PS:      p["VALID PID5 Psychoticism"] || "",
    VALID_DSM_Cluster:  p["VALID DSM Cluster"] || "",
    // Health
    VALID_WHO5:         p["VALID WHO5"] || "",
    VALID_WHO5_Level:   p["VALID WHO5 Level"] || "",
    VALID_PHQ9:         p["VALID PHQ9"] || "",
    VALID_PHQ9_Level:   p["VALID PHQ9 Level"] || "",
    VALID_GAD7:         p["VALID GAD7"] || "",
    VALID_GAD7_Level:   p["VALID GAD7 Level"] || "",
    VALID_RSES:         p["VALID RSES"] || "",
    VALID_RSES_Level:   p["VALID RSES Level"] || "",
    // Risk
    VALID_CSSRS_Level:  p["VALID CSSRS Level"] || "",
    VALID_CSSRS_Label:  p["VALID CSSRS Label"] || "",
    VALID_AUDIT_Score:  p["VALID AUDIT Score"] || "",
    VALID_AUDIT_Label:  p["VALID AUDIT Label"] || "",
    // Link status
    VISTA_VALID_Linked: existing ? "BOTH_COMPLETE" : "VALID_ONLY",
    Retest_Count:       retestCount,
    Last_Updated:       now,
  };

  upsertRow(sh, ADULT_COLS, data, existing, "UID");
  return { status:"ok", uid: data.UID, linked: existing ? true : false, action: existing ? "linked_updated" : "created" };
}

// ══════════════════════════════════════════════════════════════════════════════
//  eSMART CHILD HANDLER (C / P / V)
// ══════════════════════════════════════════════════════════════════════════════
function handleChild(p, module) {
  ensureSheet(SH.CHILD, CHILD_COLS);
  const sh   = getSheet(SH.CHILD);
  const fno  = p.FileNo || p.fileNo || "";
  const now  = new Date().toISOString();

  if (!fno) return { status:"error", msg:"FileNo required for eSMART modules" };

  // Find existing row by FileNo
  const existing = findRow(sh, "FileNo", fno);
  const retestCount = existing ? (Number(getCellValue(sh, existing, "Retest_Count")) || 0) : 0;

  const base = {
    FileNo:        fno,
    Mobile_Parent: hashMobile(p.Mobile_Parent || p.Mobile || ""),
    ChildName:     p.ChildName || p.childName || "",
    DOB:           p.DOB || p.dob || "",
    AgeYrs:        p.AgeYrs || p.age || "",
    Gender:        p.Gender || p.gender || "",
    School:        p.School || p.school || "",
    Grade:         p.Grade || p.grade || "",
    AgeGroup:      p.AgeGroup || "",
    Retest_Count:  retestCount,
    Last_Updated:  now,
  };

  let moduleData = {};

  if (module === "C") {
    moduleData = {
      C_Consent:     "YES",
      C_Consent_DT:  p.C_Consent_DT || now,
      C_Assent:      p.C_Assent || (p.childAssentGranted ? "YES" : "NOT_RECORDED"),
      C_Assent_DT:   p.C_Assent_DT || now,
      C_Start_DT:    p.C_Start_DT || now,
      C_Submit_DT:   now,
      C_Examiner:    p.Examiner || "",
      // FIS
      C_FIS_Scale:   p.C_FIS_Scale || p["FIS Scale"] || "",
      C_FIS_RawTotal:p.C_FIS_RawTotal || p["FIS Total"] || "",
      C_FIS_MA:      p.C_FIS_MA || p["FIS MA"] || "",
      C_FIS_IQ:      p.C_FIS_IQ || p["FIS IQ"] || "",
      C_FIS_IQBand:  p.C_FIS_IQBand || p["FIS Band"] || "",
      C_FIS_Pct:     p.C_FIS_Pct || p["FIS Pct"] || "",
      C_FIS_SER:     p.C_FIS_SER || "",
      C_FIS_CLS:     p.C_FIS_CLS || "",
      C_FIS_MAT:     p.C_FIS_MAT || "",
      C_FIS_CON:     p.C_FIS_CON || "",
      // SCSS
      C_ShapeCode:   p.C_ShapeCode || p.ShapeCode || "",
      C_ColorCode:   p.C_ColorCode || p.ColorCode || "",
      C_ShadeCode:   p.C_ShadeCode || p.ShadeCode || "",
      C_SmileyCode:  p.C_SmileyCode || p.SmileyCode || "",
      C_CQ:          p.C_CQ || p["SCSS CQ"] || "",
      C_IQBand_SCSS: p.C_IQBand_SCSS || "",
      C_EQSS:        p.C_EQSS || "",
      C_EQBand:      p.C_EQBand || "",
      C_MHI:         p.C_MHI || "",
      C_AnxIdx:      p.C_AnxIdx || "",
      C_AnxLevel:    p.C_AnxLevel || "",
      C_DepIdx:      p.C_DepIdx || "",
      C_DepLevel:    p.C_DepLevel || "",
      C_SFI:         p.C_SFI || "",
      C_WBI:         p.C_WBI || "",
      C_DSMCluster:  p.C_DSMCluster || "",
      C_SIR:         p.C_SIR || "",
      C_SUR:         p.C_SUR || "",
      C_CDR:         p.C_CDR || "",
      C_CRI:         p.C_CRI || "",
      C_Complete:    "YES",
    };
  }

  if (module === "P") {
    moduleData = {
      P_Consent:    "YES",
      P_Consent_DT: p.P_Consent_DT || now,
      P_Start_DT:   p.P_Start_DT || now,
      P_Submit_DT:  now,
      P_Informant:  p.InformantName || "",
      P_Relation:   p.Relation || "",
      P_PeriRiskLevel: p.P_PeriRiskLevel || "",
      P_PeriRiskCount: p.P_PeriRiskCount || "",
      P_IDD_score:  p.P_IDD_score || "", P_IDD_sev:  p.P_IDD_sev || "",
      P_ADHD_score: p.P_ADHD_score || "",P_ADHD_sev: p.P_ADHD_sev || "",
      P_ASD_score:  p.P_ASD_score || "", P_ASD_sev:  p.P_ASD_sev || "",
      P_SLD_score:  p.P_SLD_score || "", P_SLD_sev:  p.P_SLD_sev || "",
      P_MDD_score:  p.P_MDD_score || "", P_MDD_sev:  p.P_MDD_sev || "",
      P_ANX_score:  p.P_ANX_score || "", P_ANX_sev:  p.P_ANX_sev || "",
      P_ODD_score:  p.P_ODD_score || "", P_ODD_sev:  p.P_ODD_sev || "",
      P_CD_score:   p.P_CD_score || "",  P_CD_sev:   p.P_CD_sev || "",
      P_RiskTag:    p.P_RiskTag || "",
      P_SuicideFlag:p.P_SuicideFlag || "",
      P_Complete:   "YES",
    };
  }

  if (module === "V") {
    moduleData = {
      V_Consent:    "YES",
      V_Consent_DT: p.V_Consent_DT || now,
      V_Start_DT:   p.V_Start_DT || now,
      V_Submit_DT:  now,
      V_Clinician:  p.Examiner || p.Clinician || "",
      V_MISIC_FSIQ: p.V_MISIC_FSIQ || "",
      V_WISC_FSIQ:  p.V_WISC_FSIQ || "",
      V_RAVENS_Pct: p.V_RAVENS_Pct || "",
      V_CFIT_IQ:    p.V_CFIT_IQ || "",
      V_VABS_ABC:   p.V_VABS_ABC || "",
      V_CARS_Total: p.V_CARS_Total || "",
      V_SNAP_Total: p.V_SNAP_Total || "",
      V_CDI_Total:  p.V_CDI_Total || "",
      V_SCARED_Total:p.V_SCARED_Total || "",
      V_SDQ_Total:  p.V_SDQ_Total || "",
      // Diagnoses
      ...buildDxFields(p, ["IDD","ADHD","ASD","SLD","MDD","ANX","ODD","CD"]),
      V_SIR:        p.V_SIR || "",
      V_SUR:        p.V_SUR || "",
      V_CDR:        p.V_CDR || "",
      V_Prognosis:  p.V_Prognosis || "",
      V_NextReview: p.V_NextReview || "",
      V_Impression: p.V_Impression || "",
      V_Treatment:  p.V_Treatment || "",
      V_Complete:   "YES",
    };
  }

  const combined = { ...base, ...moduleData };

  // Compute All_Complete after upsert
  const row = upsertRow(sh, CHILD_COLS, combined, existing, "FileNo");
  // Check all three modules
  const cC = getCellValue(sh, row, "C_Complete") === "YES";
  const pC = getCellValue(sh, row, "P_Complete") === "YES";
  const vC = getCellValue(sh, row, "V_Complete") === "YES";
  setCellValue(sh, row, "All_Complete", (cC && pC && vC) ? "YES" : "NO");

  return {
    status: "ok",
    fileNo: fno,
    module,
    action: existing ? "updated" : "created",
    allComplete: cC && pC && vC,
    retest: retestCount > 0,
  };
}

// ══════════════════════════════════════════════════════════════════════════════
//  HUB ADMIN HANDLER
// ══════════════════════════════════════════════════════════════════════════════
function handleHub(p) {
  const auth = p.auth || p.Auth || "";
  if (auth !== MASTER_PASSWORD && auth !== HUB_PASSWORD) {
    return { status:"error", msg:"Unauthorised" };
  }

  const action = p.action || "";
  const now = new Date().toISOString();

  // Register new ANM/MHW
  if (action === "register_worker") {
    ensureSheet(SH.HUB, HUB_COLS);
    const sh = getSheet(SH.HUB);
    const hubId = "HUB-" + (p.CenterCode || "XX") + "-" + Date.now().toString(36).toUpperCase().slice(-4);
    const row = {
      HubID: hubId, HubName: p.HubName || "", Role: p.Role || "ANM",
      Mobile: p.Mobile || "", Village: p.Village || "", District: p.District || "",
      State: p.State || "Maharashtra", CenterCode: p.CenterCode || "",
      CreatedDT: now, LastActiveDT: now, SubjectsAssigned: 0,
      Password: p.Password || HUB_PASSWORD, Active: "YES",
    };
    appendRow(sh, HUB_COLS, row);
    return { status:"ok", hubId, action:"registered" };
  }

  // Generate assessment link
  if (action === "generate_link") {
    ensureSheet(SH.LINKS, ["LinkID","HubID","Type","FileNo_or_UID","SubjectName","AgeApprox","Gender","SentTo","SentDT","OpenedDT","CompletedDT","URL","Notes"]);
    const sh = getSheet(SH.LINKS);
    const linkId = "LNK-" + Date.now().toString(36).toUpperCase().slice(-8);
    const baseUrl = p.BaseURL || "https://cibs-battery.vercel.app";
    const params  = new Object();
    if (p.FileNo) params.fileNo = p.FileNo;
    if (p.HubID)  params.hub   = p.HubID;
    if (p.Type)   params.tool  = p.Type;
    const paramStr = Object.entries(params).map(([k,v])=>`${k}=${encodeURIComponent(v)}`).join("&");
    const url = baseUrl + (paramStr ? "?" + paramStr : "");
    const row = {
      LinkID: linkId, HubID: p.HubID || "", Type: p.Type || "vista",
      "FileNo_or_UID": p.FileNo || p.UID || "",
      SubjectName: p.SubjectName || "", AgeApprox: p.AgeApprox || "",
      Gender: p.Gender || "", SentTo: p.SentTo || "",
      SentDT: now, OpenedDT: "", CompletedDT: "", URL: url, Notes: p.Notes || "",
    };
    appendRow(sh, ["LinkID","HubID","Type","FileNo_or_UID","SubjectName","AgeApprox","Gender","SentTo","SentDT","OpenedDT","CompletedDT","URL","Notes"], row);
    return { status:"ok", linkId, url, action:"link_generated" };
  }

  // Get stats dashboard
  if (action === "stats") {
    const adultSh = getSheet(SH.ADULT);
    const childSh = getSheet(SH.CHILD);
    const adultCount  = adultSh  ? Math.max(0, adultSh.getLastRow()  - 1) : 0;
    const childCount  = childSh  ? Math.max(0, childSh.getLastRow()  - 1) : 0;
    return { status:"ok", adultSubjects: adultCount, childSubjects: childCount, ts: now };
  }

  return { status:"error", msg:"Unknown hub action: " + action };
}

// ══════════════════════════════════════════════════════════════════════════════
//  READ HANDLER — returns sheet data for Hub Dashboard
// ══════════════════════════════════════════════════════════════════════════════
function handleRead(p) {
  const auth = p.auth || "";
  if (auth !== MASTER_PASSWORD && auth !== HUB_PASSWORD) {
    return { status:"error", msg:"Unauthorised" };
  }
  const shName = p.sheet || SH.ADULT;
  const sh = getSheet(shName);
  if (!sh) return { status:"ok", data:[], cols:[] };
  const values = sh.getDataRange().getValues();
  if (values.length < 1) return { status:"ok", data:[], cols:[] };
  const cols = values[0];
  const rows = values.slice(1).map(row => {
    const obj = {};
    cols.forEach((c,i) => { obj[c] = row[i]; });
    return obj;
  });
  return { status:"ok", cols, data: rows, total: rows.length };
}

// ══════════════════════════════════════════════════════════════════════════════
//  EXPORT HANDLER — returns CSV / JSON for download
// ══════════════════════════════════════════════════════════════════════════════
function handleExport(p) {
  const auth = p.auth || "";
  if (auth !== MASTER_PASSWORD) return { status:"error", msg:"Unauthorised" };
  const res = handleRead({ auth, sheet: p.sheet || SH.ADULT });
  if (res.status !== "ok") return res;
  if (p.format === "csv") {
    const header = res.cols.join(",");
    const rows   = res.data.map(r => res.cols.map(c => escapeCsv(r[c])).join(","));
    return { status:"ok", csv: [header, ...rows].join("\n"), total: res.data.length };
  }
  return res; // JSON by default
}

// ══════════════════════════════════════════════════════════════════════════════
//  UTILITIES
// ══════════════════════════════════════════════════════════════════════════════
function ensureSheet(name, cols) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, cols.length).setValues([cols]);
    sh.getRange(1, 1, 1, cols.length)
      .setBackground("#1e3a5f").setFontColor("white").setFontWeight("bold");
    sh.setFrozenRows(1);
  }
  return sh;
}

function getSheet(name) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function findRow(sh, colName, value) {
  if (!sh || !value) return null;
  const vals = sh.getDataRange().getValues();
  const header = vals[0];
  const ci = header.indexOf(colName);
  if (ci < 0) return null;
  for (let r = 1; r < vals.length; r++) {
    if (String(vals[r][ci]) === String(value)) return r + 1; // 1-indexed row
  }
  return null;
}

function findRowByMobile(sh, hashedMobile) {
  return findRow(sh, "Mobile", hashedMobile);
}

function getCellValue(sh, rowNum, colName) {
  const vals = sh.getDataRange().getValues();
  const header = vals[0];
  const ci = header.indexOf(colName);
  if (ci < 0 || !rowNum) return "";
  return vals[rowNum - 1][ci];
}

function setCellValue(sh, rowNum, colName, value) {
  const vals = sh.getDataRange().getValues();
  const header = vals[0];
  const ci = header.indexOf(colName);
  if (ci < 0 || !rowNum) return;
  sh.getRange(rowNum, ci + 1).setValue(value);
}

function upsertRow(sh, cols, data, existingRow, keyCol) {
  if (existingRow) {
    // Update existing — only write non-empty values (preserve existing data)
    const header = sh.getDataRange().getValues()[0];
    Object.entries(data).forEach(([k, v]) => {
      if (v === "" || v === null || v === undefined) return; // don't overwrite with blank
      if (k === "Retest_Count") return; // handled separately
      const ci = header.indexOf(k);
      if (ci >= 0) sh.getRange(existingRow, ci + 1).setValue(v);
    });
    return existingRow;
  } else {
    // Append new row
    appendRow(sh, cols, data);
    return sh.getLastRow();
  }
}

function appendRow(sh, cols, data) {
  const row = cols.map(c => data[c] !== undefined ? data[c] : "");
  sh.appendRow(row);
}

function generateAdultUID(mobile, gender) {
  const m6   = (mobile || "").replace(/\D/g,"").slice(-6).padStart(6,"0");
  const now  = new Date();
  const dd   = String(now.getDate()).padStart(2,"0");
  const mm   = String(now.getMonth()+1).padStart(2,"0");
  const yy   = String(now.getFullYear()).slice(-2);
  const g    = (gender || "X")[0].toUpperCase();
  return `AV-${m6}-${dd}${mm}${yy}-${g}`;
}

function hashMobile(mobile) {
  // Simple deterministic hash — preserves re-test detection without storing raw PII
  const m = (mobile || "").replace(/\D/g,"").slice(-10);
  if (!m) return "";
  // XOR-fold to 8 chars — not cryptographic but sufficient for dedup
  let h = 0;
  for (let i = 0; i < m.length; i++) h = ((h << 3) ^ m.charCodeAt(i)) & 0x7FFFFFFF;
  return "M" + h.toString(16).toUpperCase().padStart(8,"0");
}

function buildDxFields(p, domains) {
  const out = {};
  domains.forEach(d => {
    out[`V_${d}_Dx`]  = p[`V_${d}_Dx`]  || p[`${d}_Dx`]  || "";
    out[`V_${d}_Code`] = p[`V_${d}_Code`] || "";
    out[`V_${d}_Sev`]  = p[`V_${d}_Sev`]  || p[`V_${d}_ClinicianSev`] || "";
  });
  return out;
}

function escapeCsv(v) {
  const s = String(v === null || v === undefined ? "" : v);
  return (s.includes(",") || s.includes('"') || s.includes("\n"))
    ? `"${s.replace(/"/g,'""')}"` : s;
}

function writeAudit(source, uid, statusStr, payloadSize) {
  try {
    ensureSheet(SH.AUDIT, ["Timestamp","Source","UID","Status","PayloadBytes","GAS_Version"]);
    const sh = getSheet(SH.AUDIT);
    sh.appendRow([new Date().toISOString(), source, uid, statusStr, payloadSize, VERSION]);
  } catch(e) { /* never let audit failure break submission */ }
}

// ── Self-setup on install ──────────────────────────────────────────────────
function onOpen() {
  ensureSheet(SH.ADULT,  ADULT_COLS);
  ensureSheet(SH.CHILD,  CHILD_COLS);
  ensureSheet(SH.HUB,    HUB_COLS);
  ensureSheet(SH.LINKS,  ["LinkID","HubID","Type","FileNo_or_UID","SubjectName","AgeApprox","Gender","SentTo","SentDT","OpenedDT","CompletedDT","URL","Notes"]);
  ensureSheet(SH.AUDIT,  ["Timestamp","Source","UID","Status","PayloadBytes","GAS_Version"]);
  SpreadsheetApp.getUi().alert("CIBS Unified Backend v" + VERSION + " initialised. All sheets ready.");
}
